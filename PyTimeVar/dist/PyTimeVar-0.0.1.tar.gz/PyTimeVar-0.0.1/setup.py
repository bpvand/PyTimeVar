import setuptools

setuptools.setup(
    name='PyTimeVar',
    version="0.0.1",
    python_requires=">=3.9",
    packages=['PyTimeVar', 'tests']
)
