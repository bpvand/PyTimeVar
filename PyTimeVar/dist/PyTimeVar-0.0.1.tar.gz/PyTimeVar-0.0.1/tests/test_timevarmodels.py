import timevarmodels as tvm

def test_version():
  assert tvm.__version__ == '0.0.1'